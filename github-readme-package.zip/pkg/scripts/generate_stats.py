#!/usr/bin/env python3
"""
Regenerates stats.svg, langs.svg and trophies.svg from live GitHub data.
Run locally (needs `requests`) or via .github/workflows/update-stats.yml,
which runs this on a schedule and commits the refreshed SVGs.

No third-party card services are used -- this hits the public GitHub REST
API directly and renders the local SVG templates below.
"""
import os
import sys
import json
import urllib.request

USERNAME = os.environ.get("GH_USERNAME", "ehtasham4943")
TOKEN = os.environ.get("GITHUB_TOKEN", "")

API = "https://api.github.com"

pink = "#ff5fb0"
purple = "#8b3fd1"
bg = "#1a0b2e"
card = "#ffffff10"
stroke = "#ffffff22"
ink = "#f6e9ff"
sub = "#d9b3f0"

LANG_COLORS = {
    "JavaScript": "#f1e05a", "TypeScript": "#3178c6", "C": "#555555",
    "C++": "#f34b7d", "HTML": "#e34c26", "CSS": "#563d7c",
    "MATLAB": "#e16737", "Python": "#3572A5", "Jupyter Notebook": "#DA5B0B",
    "Shell": "#89e051", "Java": "#b07219",
}


def gh_get(path):
    req = urllib.request.Request(f"{API}{path}")
    req.add_header("Accept", "application/vnd.github+json")
    req.add_header("User-Agent", USERNAME)
    if TOKEN:
        req.add_header("Authorization", f"Bearer {TOKEN}")
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def fetch_profile():
    user = gh_get(f"/users/{USERNAME}")
    repos = gh_get(f"/users/{USERNAME}/repos?per_page=100&type=owner")

    total_stars = sum(r.get("stargazers_count", 0) for r in repos)
    lang_bytes = {}
    for r in repos:
        if r.get("fork"):
            continue
        try:
            langs = gh_get(f"/repos/{USERNAME}/{r['name']}/languages")
        except Exception:
            langs = {}
        for lang, n in langs.items():
            lang_bytes[lang] = lang_bytes.get(lang, 0) + n

    return {
        "public_repos": user.get("public_repos", 0),
        "followers": user.get("followers", 0),
        "total_stars": total_stars,
        "lang_bytes": lang_bytes,
    }


def build_stats_svg(profile):
    W, H = 460, 230
    stats = [
        ("Public Repos", profile["public_repos"], max(profile["public_repos"], 20)),
        ("Total Stars", profile["total_stars"], max(profile["total_stars"], 10)),
        ("Followers", profile["followers"], max(profile["followers"], 15)),
    ]
    rank_pct = min(100, 40 + profile["public_repos"] * 2 + profile["total_stars"] * 3)
    circumference = 2 * 3.14159 * 54
    dash_target = circumference * rank_pct / 100

    rows = []
    for i, (label, val, maxv) in enumerate(stats):
        y = i * 40
        barw = 190 * min(val / maxv, 1.0) if maxv else 0
        delay = 0.5 + i * 0.18
        rows.append(f'''<g transform="translate(0,{y})" opacity="0">
    <animate attributeName="opacity" from="0" to="1" begin="{delay:.2f}s" dur="0.5s" fill="freeze"/>
    <animateTransform attributeName="transform" type="translate" additive="sum" values="-40,0;0,0" begin="{delay:.2f}s" dur="0.5s" fill="freeze" calcMode="spline" keySplines="0.2 0.8 0.2 1"/>
    <text x="0" y="14" font-family="'Segoe UI',sans-serif" font-size="13" fill="{sub}">{esc(label)}</text>
    <text x="230" y="14" text-anchor="end" font-family="'Segoe UI',sans-serif" font-size="13" font-weight="700" fill="{ink}">{val}</text>
    <rect x="0" y="22" width="230" height="6" rx="3" fill="{card}" stroke="{stroke}"/>
    <rect x="0" y="22" width="0" height="6" rx="3" fill="url(#barGrad)">
      <animate attributeName="width" from="0" to="{barw:.0f}" begin="{delay+0.15:.2f}s" dur="0.9s" fill="freeze" calcMode="spline" keySplines="0.2 0.8 0.2 1"/>
    </rect>
  </g>''')
    rows_svg = "\n".join(rows)

    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">
  <defs>
    <linearGradient id="barGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="{pink}"/><stop offset="100%" stop-color="{purple}"/>
    </linearGradient>
    <clipPath id="statsRound"><rect width="{W}" height="{H}" rx="18"/></clipPath>
  </defs>
  <g clip-path="url(#statsRound)">
    <rect width="{W}" height="{H}" fill="{bg}"/>
    <text x="20" y="30" font-family="'Segoe UI',sans-serif" font-size="15" font-weight="700" fill="{ink}">GitHub Stats</text>
    <g transform="translate({W-95},20)">
      <circle cx="40" cy="40" r="34" fill="none" stroke="{card}" stroke-width="8"/>
      <circle cx="40" cy="40" r="34" fill="none" stroke="url(#barGrad)" stroke-width="8" stroke-linecap="round"
        stroke-dasharray="{circumference:.1f}" stroke-dashoffset="{circumference:.1f}" transform="rotate(-90 40 40)">
        <animate attributeName="stroke-dashoffset" from="{circumference:.1f}" to="{circumference-dash_target:.1f}" begin="0.3s" dur="1.4s" fill="freeze" calcMode="spline" keySplines="0.2 0.8 0.2 1"/>
      </circle>
      <text x="40" y="46" text-anchor="middle" font-family="'Segoe UI',sans-serif" font-size="18" font-weight="700" fill="{ink}">{rank_pct}%</text>
    </g>
    <g transform="translate(20,64)">
      {rows_svg}
    </g>
  </g>
</svg>'''


def build_langs_svg(profile):
    W, H = 340, 230
    total = sum(profile["lang_bytes"].values()) or 1
    items = sorted(profile["lang_bytes"].items(), key=lambda kv: -kv[1])[:6]
    if not items:
        items = [("No data yet", 1)]
        total = 1
    rows = []
    for i, (name, n) in enumerate(items):
        pct = round(100 * n / total)
        col = LANG_COLORS.get(name, "#8b3fd1")
        y = i * 30
        delay = 0.4 + i * 0.15
        barw = 200 * pct / 100
        rows.append(f'''<g transform="translate(0,{y})">
    <circle cx="4" cy="-4" r="4" fill="{col}"/>
    <text x="14" y="0" font-family="'Segoe UI',sans-serif" font-size="12.5" fill="{sub}">{esc(name)}</text>
    <text x="240" y="0" text-anchor="end" font-family="'Segoe UI',sans-serif" font-size="12.5" fill="{ink}">{pct}%</text>
    <rect x="0" y="6" width="200" height="7" rx="3.5" fill="{card}"/>
    <rect x="0" y="6" width="0" height="7" rx="3.5" fill="{col}">
      <animate attributeName="width" from="0" to="{barw:.0f}" begin="{delay:.2f}s" dur="0.9s" fill="freeze" calcMode="spline" keySplines="0.2 0.8 0.2 1"/>
    </rect>
  </g>''')
    rows_svg = "\n".join(rows)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">
  <defs><clipPath id="langsRound"><rect width="{W}" height="{H}" rx="18"/></clipPath></defs>
  <g clip-path="url(#langsRound)">
    <rect width="{W}" height="{H}" fill="{bg}"/>
    <text x="20" y="28" font-family="'Segoe UI',sans-serif" font-size="15" font-weight="700" fill="{ink}">Most Used Languages</text>
    <g transform="translate(20,54)">{rows_svg}</g>
  </g>
</svg>'''


def build_trophies_svg(profile):
    W, H = 700, 170
    def rank(n, thresholds):
        labels = ["C", "B", "B+", "A-", "A", "S"]
        idx = 0
        for i, t in enumerate(thresholds):
            if n >= t:
                idx = i + 1
        return labels[min(idx, len(labels) - 1)]

    trophies = [
        ("Repositories", rank(profile["public_repos"], [3, 6, 10, 15, 25]), purple),
        ("Stars", rank(profile["total_stars"], [1, 3, 6, 10, 20]), "#ffb84d"),
        ("Followers", rank(profile["followers"], [3, 6, 12, 20, 40]), "#4dd0e1"),
    ]
    cell_w = 128
    cells = []
    for i, (label, r, col) in enumerate(trophies):
        x = i * (cell_w + 8)
        delay = 0.3 + i * 0.18
        cells.append(f'''<g opacity="0">
    <animate attributeName="opacity" from="0" to="1" begin="{delay:.2f}s" dur="0.4s" fill="freeze"/>
    <rect x="{x}" y="10" width="{cell_w}" height="150" rx="14" fill="{card}" stroke="{stroke}"/>
    <circle cx="{x+cell_w/2}" cy="60" r="26" fill="none" stroke="{col}" stroke-width="4"/>
    <text x="{x+cell_w/2}" y="68" text-anchor="middle" font-family="'Segoe UI',sans-serif" font-size="20" font-weight="700" fill="{col}">{r}</text>
    <text x="{x+cell_w/2}" y="110" text-anchor="middle" font-family="'Segoe UI',sans-serif" font-size="12" fill="{ink}">{esc(label)}</text>
    <rect x="{x}" y="10" width="40" height="150" fill="#ffffff" opacity="0.12" transform="skewX(-20)">
      <animate attributeName="x" from="{x-60}" to="{x+cell_w+60}" begin="{delay+1.2:.2f}s" dur="1.6s" repeatCount="indefinite"/>
    </rect>
  </g>''')
    cells_svg = "\n".join(cells)
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">
  <defs><clipPath id="trophRound"><rect width="{W}" height="{H}" rx="18"/></clipPath></defs>
  <g clip-path="url(#trophRound)">
    <rect width="{W}" height="{H}" fill="{bg}"/>
    <g transform="translate(10,0)">{cells_svg}</g>
  </g>
</svg>'''


def main():
    try:
        profile = fetch_profile()
    except Exception as e:
        print(f"Could not reach the GitHub API ({e}); leaving existing SVGs untouched.", file=sys.stderr)
        return
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join(here, "stats.svg"), "w") as f:
        f.write(build_stats_svg(profile))
    with open(os.path.join(here, "langs.svg"), "w") as f:
        f.write(build_langs_svg(profile))
    with open(os.path.join(here, "trophies.svg"), "w") as f:
        f.write(build_trophies_svg(profile))
    print("Updated stats.svg, langs.svg, trophies.svg from live GitHub data.")


if __name__ == "__main__":
    main()
