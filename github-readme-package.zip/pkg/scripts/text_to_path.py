import sys
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen

def text_to_path(text, font_path, font_size, x_start=0, y_start=0, letter_spacing=0):
    font = TTFont(font_path)
    glyph_set = font.getGlyphSet()
    cmap = font.getBestCmap()
    units_per_em = font['head'].unitsPerEm
    scale = font_size / units_per_em

    hmtx = font['hmtx']
    cursor_x = x_start
    paths = []
    for ch in text:
        if ch == ' ':
            # advance by space glyph width if present
            glyph_name = cmap.get(ord(' '))
            if glyph_name:
                adv = hmtx[glyph_name][0]
            else:
                adv = units_per_em * 0.28
            cursor_x += adv * scale + letter_spacing
            continue
        code = ord(ch)
        glyph_name = cmap.get(code)
        if not glyph_name:
            continue
        pen = SVGPathPen(glyph_set)
        glyph_set[glyph_name].draw(pen)
        d = pen.getCommands()
        adv = hmtx[glyph_name][0]
        # transform: scale font units -> px, flip y (font y-up -> svg y-down), translate
        tx = cursor_x
        ty = y_start
        paths.append((d, tx, ty, scale))
        cursor_x += adv * scale + letter_spacing
    return paths, cursor_x

if __name__ == '__main__':
    text = sys.argv[1]
    font_path = sys.argv[2]
    font_size = float(sys.argv[3])
    paths, total_w = text_to_path(text, font_path, font_size)
    print(f"<!-- total width: {total_w} -->")
    for d, tx, ty, scale in paths:
        print(f'<path d="{d}" transform="translate({tx},{ty}) scale({scale},{-scale})" />')
