import random
random.seed(5)

pink = "#ff5fb0"
purple = "#8b3fd1"
bg = "#1a0b2e"
card = "#ffffff10"
stroke = "#ffffff22"
ink = "#f6e9ff"
sub = "#d9b3f0"

def esc(s):
    return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

# ---------- stats.svg ----------
W1, H1 = 460, 230
stats = [("Public Repos", 13, 40), ("Total Stars", 5, 20), ("Followers", 8, 25), ("This Year's Commits", 240, 400)]
rank_pct = 78  # placeholder "profile strength" ring, refreshed by the Action

circumference = 2*3.14159*54
dash_target = circumference * rank_pct/100

rows = []
for i,(label,val,maxv) in enumerate(stats):
    y = i*40
    barw = 190*min(val/maxv,1.0)
    delay = 0.5 + i*0.18
    rows.append(f'''<g transform="translate(0,{y})" opacity="0">
    <animate attributeName="opacity" from="0" to="1" begin="{delay:.2f}s" dur="0.5s" fill="freeze"/>
    <animateTransform attributeName="transform" type="translate" additive="sum" values="-40,0;0,0" begin="{delay:.2f}s" dur="0.5s" fill="freeze" calcMode="spline" keySplines="0.2 0.8 0.2 1"/>
    <text x="0" y="14" font-family="'Segoe UI',sans-serif" font-size="13" fill="{sub}">{esc(label)}</text>
    <text x="230" y="14" text-anchor="end" font-family="'Segoe UI',sans-serif" font-size="13" font-weight="700" fill="{ink}">{val}</text>
    <rect x="0" y="22" width="230" height="6" rx="3" fill="{card}" stroke="{stroke}"/>
    <rect x="0" y="22" width="0" height="6" rx="3" fill="url(#barGrad)">
      <animate attributeName="width" from="0" to="{barw:.0f}" begin="{delay+0.15:.2f}s" dur="0.9s" fill="freeze" calcMode="spline" keySplines="0.2 0.8 0.2 1"/>
    </rect>
  </g>''')
rows_svg = "\n".join(rows)

stats_svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W1} {H1}" width="{W1}" height="{H1}">
  <defs>
    <linearGradient id="barGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="{pink}"/><stop offset="100%" stop-color="{purple}"/>
    </linearGradient>
    <clipPath id="statsRound"><rect width="{W1}" height="{H1}" rx="18"/></clipPath>
  </defs>
  <g clip-path="url(#statsRound)">
    <rect width="{W1}" height="{H1}" fill="{bg}"/>
    <text x="20" y="30" font-family="'Segoe UI',sans-serif" font-size="15" font-weight="700" fill="{ink}">GitHub Stats</text>
    <g transform="translate({W1-95},20)">
      <circle cx="40" cy="40" r="34" fill="none" stroke="{card}" stroke-width="8"/>
      <circle cx="40" cy="40" r="34" fill="none" stroke="url(#barGrad)" stroke-width="8" stroke-linecap="round"
        stroke-dasharray="{circumference:.1f}" stroke-dashoffset="{circumference:.1f}" transform="rotate(-90 40 40)">
        <animate attributeName="stroke-dashoffset" from="{circumference:.1f}" to="{circumference-dash_target:.1f}" begin="0.3s" dur="1.4s" fill="freeze" calcMode="spline" keySplines="0.2 0.8 0.2 1"/>
      </circle>
      <text x="40" y="46" text-anchor="middle" font-family="'Segoe UI',sans-serif" font-size="18" font-weight="700" fill="{ink}">{rank_pct}%</text>
    </g>
    <g transform="translate(20,64)">
      {rows_svg}
    </g>
  </g>
</svg>'''
open('/home/claude/work/pkg/stats.svg','w').write(stats_svg)

# ---------- langs.svg ----------
W2, H2 = 340, 230
langs = [("JavaScript", 34, "#f1e05a"), ("C / C++", 24, "#f34b7d"), ("HTML", 16, "#e34c26"),
         ("CSS", 12, "#563d7c"), ("MATLAB", 9, "#e16737"), ("Other", 5, "#8b3fd1")]
lang_rows = []
for i,(name,pct,col) in enumerate(langs):
    y = i*30
    delay = 0.4 + i*0.15
    barw = 200*pct/100
    lang_rows.append(f'''<g transform="translate(0,{y})">
    <circle cx="4" cy="-4" r="4" fill="{col}"/>
    <text x="14" y="0" font-family="'Segoe UI',sans-serif" font-size="12.5" fill="{sub}">{esc(name)}</text>
    <text x="240" y="0" text-anchor="end" font-family="'Segoe UI',sans-serif" font-size="12.5" fill="{ink}">{pct}%</text>
    <rect x="0" y="6" width="200" height="7" rx="3.5" fill="{card}"/>
    <rect x="0" y="6" width="0" height="7" rx="3.5" fill="{col}">
      <animate attributeName="width" from="0" to="{barw:.0f}" begin="{delay:.2f}s" dur="0.9s" fill="freeze" calcMode="spline" keySplines="0.2 0.8 0.2 1"/>
    </rect>
  </g>''')
lang_rows_svg = "\n".join(lang_rows)
langs_svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W2} {H2}" width="{W2}" height="{H2}">
  <defs><clipPath id="langsRound"><rect width="{W2}" height="{H2}" rx="18"/></clipPath></defs>
  <g clip-path="url(#langsRound)">
    <rect width="{W2}" height="{H2}" fill="{bg}"/>
    <text x="20" y="28" font-family="'Segoe UI',sans-serif" font-size="15" font-weight="700" fill="{ink}">Most Used Languages</text>
    <g transform="translate(20,54)">{lang_rows_svg}</g>
  </g>
</svg>'''
open('/home/claude/work/pkg/langs.svg','w').write(langs_svg)

# ---------- trophies.svg ----------
W3, H3 = 700, 170
trophies = [("Commit Streak", "S", pink), ("Repositories", "A", purple), ("Stars", "B+", "#ffb84d"),
            ("Followers", "B", "#4dd0e1"), ("Pull Requests", "A-", "#8affa0")]
cell_w = 128
cells = []
for i,(label,rank,col) in enumerate(trophies):
    x = i*(cell_w+8)
    delay = 0.3 + i*0.18
    cells.append(f'''<g transform="translate({x},0) scale(0.7)" opacity="0" style="transform-origin:{x+cell_w/2}px 75px">
    <animate attributeName="opacity" from="0" to="1" begin="{delay:.2f}s" dur="0.4s" fill="freeze"/>
    <animateTransform attributeName="transform" type="scale" additive="sum" values="0.3,0.3;1,1" begin="{delay:.2f}s" dur="0.45s" fill="freeze" calcMode="spline" keySplines="0.3 1.4 0.4 1"/>
    <rect x="{x}" y="10" width="{cell_w}" height="150" rx="14" fill="{card}" stroke="{stroke}"/>
    <circle cx="{x+cell_w/2}" cy="60" r="26" fill="none" stroke="{col}" stroke-width="4"/>
    <text x="{x+cell_w/2}" y="68" text-anchor="middle" font-family="'Segoe UI',sans-serif" font-size="20" font-weight="700" fill="{col}">{rank}</text>
    <text x="{x+cell_w/2}" y="110" text-anchor="middle" font-family="'Segoe UI',sans-serif" font-size="12" fill="{ink}">{esc(label)}</text>
    <rect x="{x}" y="10" width="40" height="150" fill="#ffffff" opacity="0.12" transform="skewX(-20)">
      <animate attributeName="x" from="{x-60}" to="{x+cell_w+60}" begin="{delay+1.2:.2f}s" dur="1.6s" repeatCount="indefinite"/>
    </rect>
  </g>''')
cells_svg = "\n".join(cells)
trophies_svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W3} {H3}" width="{W3}" height="{H3}">
  <defs><clipPath id="trophRound"><rect width="{W3}" height="{H3}" rx="18"/></clipPath></defs>
  <g clip-path="url(#trophRound)">
    <rect width="{W3}" height="{H3}" fill="{bg}"/>
    <g transform="translate(10,0)">{cells_svg}</g>
  </g>
</svg>'''
open('/home/claude/work/pkg/trophies.svg','w').write(trophies_svg)

print("stats", len(stats_svg), "langs", len(langs_svg), "trophies", len(trophies_svg))
