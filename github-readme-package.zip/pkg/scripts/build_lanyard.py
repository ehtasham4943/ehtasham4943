import sys, os, base64, random

AVATAR_B64 = open('/home/claude/work/avatar_final.png.b64').read().strip()

W, H = 420, 640
NAME = "Ehtasham Khalid"
ROLE = "Electrical Engineer"
HANDLE = "@ehtasham4943"
STRAP_TEXT = "ISSB APP  \u2022  EHTASHAM KHALID  \u2022  "

pink = "#ff5fb0"
pinkDark = "#c93f8a"
purple = "#8b3fd1"
glass = "#1c1030"
glassBorder = "#ffffff33"
ink = "#f6e9ff"
sub = "#d9b3f0"

def esc(s):
    return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

# barcode bars
random.seed(3)
bars = []
bx = 0
for i in range(28):
    w = random.choice([2,2,3,4,2,5])
    if random.random() > 0.35:
        bars.append(f'<rect x="{bx}" y="0" width="{w}" height="30" fill="#1c1030"/>')
    bx += w + 2
barcode_w = bx

card_w, card_h = 300, 300
card_x, card_y = -card_w/2, 260  # local coords: swinging group is already centered at W/2
avatar_r = 54
avatar_cx, avatar_cy = card_x + card_w/2, card_y + 92

svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">
  <defs>
    <linearGradient id="strapGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="{pink}"/>
      <stop offset="100%" stop-color="{pinkDark}"/>
    </linearGradient>
    <linearGradient id="shineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0"/>
      <stop offset="45%" stop-color="#ffffff" stop-opacity="0.55"/>
      <stop offset="55%" stop-color="#ffffff" stop-opacity="0.55"/>
      <stop offset="100%" stop-color="#ffffff" stop-opacity="0"/>
    </linearGradient>
    <clipPath id="cardClip"><rect x="{card_x}" y="{card_y}" width="{card_w}" height="{card_h}" rx="20" ry="20"/></clipPath>
    <clipPath id="avatarCirc"><circle cx="{avatar_cx}" cy="{avatar_cy}" r="{avatar_r}"/></clipPath>
    <filter id="ringGlow" x="-60%" y="-60%" width="220%" height="220%">
      <feGaussianBlur stdDeviation="4" result="b"/>
      <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
    <filter id="cardGlow" x="-30%" y="-30%" width="160%" height="160%">
      <feGaussianBlur stdDeviation="10"/>
    </filter>
    <clipPath id="barcodeClip"><rect x="0" y="0" width="{barcode_w}" height="30"/></clipPath>
  </defs>

  <!-- fixed anchor (imagine clipped to top edge) -->
  <g>
    <rect x="{W/2-22}" y="0" width="44" height="14" rx="4" fill="#8a8a92"/>
    <circle cx="{W/2}" cy="20" r="9" fill="none" stroke="#8a8a92" stroke-width="5"/>
  </g>

  <!-- swinging assembly: drop-in then damped pendulum then gentle idle sway -->
  <g transform="translate({W/2},20)">
    <animateTransform attributeName="transform" type="translate" additive="sum"
      values="0,-280; 0,10; 0,-6; 0,3; 0,-1.5; 0,0.8; 0,-0.4; 0,0"
      keyTimes="0;0.42;0.55;0.66;0.76;0.85;0.93;1"
      dur="1.7s" fill="freeze" calcMode="spline"
      keySplines="0.3 0.9 0.4 1;0.3 0.4 0.6 1;0.3 0.4 0.6 1;0.3 0.4 0.6 1;0.3 0.4 0.6 1;0.3 0.4 0.6 1;0.3 0.4 0.6 1;0.3 0.4 0.6 1"/>

    <g id="pendulum" transform="rotate(0)">
      <animateTransform attributeName="transform" type="rotate"
        values="26;-19;12;-7.5;4.5;-2.8;1.7;-1;0.6;0"
        keyTimes="0;0.14;0.28;0.41;0.53;0.64;0.74;0.83;0.92;1"
        dur="1.9s" begin="0.55s" fill="freeze" calcMode="spline"
        keySplines="0.3 0 0.4 1;0.3 0 0.4 1;0.3 0 0.4 1;0.3 0 0.4 1;0.3 0 0.4 1;0.3 0 0.4 1;0.3 0 0.4 1;0.3 0 0.4 1;0.3 0 0.4 1"/>
      <animateTransform attributeName="transform" type="rotate" additive="sum"
        values="0;2.2;0;-2.2;0" keyTimes="0;0.25;0.5;0.75;1"
        dur="4.2s" begin="2.45s" repeatCount="indefinite" calcMode="spline"
        keySplines="0.4 0 0.6 1;0.4 0 0.6 1;0.4 0 0.6 1;0.4 0 0.6 1"/>

      <!-- strap -->
      <rect x="-20" y="0" width="40" height="{card_y-20}" fill="url(#strapGrad)"/>
      <g clip-path="url(#cardClip)"></g>
      <g style="isolation:isolate">
        <clipPath id="strapClip"><rect x="-20" y="0" width="40" height="{card_y-20}"/></clipPath>
        <g clip-path="url(#strapClip)">
          <text x="0" y="26" text-anchor="middle" font-family="'Segoe UI',sans-serif" font-size="10.5" font-weight="700"
            fill="#ffffff" opacity="0.92" transform="rotate(90 0 130)"
            letter-spacing="1">{esc(STRAP_TEXT * 3)}</text>
        </g>
      </g>

      <!-- metal ring joining strap to card -->
      <circle cx="0" cy="{card_y-14}" r="11" fill="none" stroke="#c9c9d1" stroke-width="4"/>
      <rect x="-4" y="{card_y-24}" width="8" height="24" fill="#c9c9d1"/>

      <!-- card -->
      <rect x="{card_x}" y="{card_y}" width="{card_w}" height="{card_h}" rx="20" fill="{glass}" opacity="0.55" filter="url(#cardGlow)"/>
      <rect x="{card_x}" y="{card_y}" width="{card_w}" height="{card_h}" rx="20" fill="{glass}" stroke="{glassBorder}" stroke-width="1.5"/>

      <g clip-path="url(#cardClip)">
        <!-- holographic shine sweep -->
        <rect x="{card_x-260}" y="{card_y}" width="220" height="{card_h}" fill="url(#shineGrad)" transform="skewX(-20)">
          <animate attributeName="x" from="{card_x-260}" to="{card_x+card_w+260}" dur="3.2s" begin="2.6s" repeatCount="indefinite"/>
        </rect>

        <!-- avatar glow ring -->
        <circle cx="{avatar_cx}" cy="{avatar_cy}" r="{avatar_r+5}" fill="none" stroke="url(#strapGrad)" stroke-width="3" filter="url(#ringGlow)">
          <animate attributeName="stroke-opacity" values="0.6;1;0.6" dur="2.4s" repeatCount="indefinite"/>
        </circle>
        <g clip-path="url(#avatarCirc)">
          <image href="data:image/png;base64,{AVATAR_B64}" x="{avatar_cx-avatar_r}" y="{avatar_cy-avatar_r}" width="{avatar_r*2}" height="{avatar_r*2}" preserveAspectRatio="xMidYMid slice"/>
        </g>
        <circle cx="{avatar_cx}" cy="{avatar_cy}" r="{avatar_r}" fill="none" stroke="{ink}" stroke-width="1.5" opacity="0.5"/>

        <text x="{card_x+card_w/2}" y="{avatar_cy+avatar_r+34}" text-anchor="middle" font-family="'Segoe UI',sans-serif" font-size="19" font-weight="700" fill="{ink}">{esc(NAME)}</text>
        <text x="{card_x+card_w/2}" y="{avatar_cy+avatar_r+56}" text-anchor="middle" font-family="'Segoe UI',sans-serif" font-size="13" fill="{pink}">{esc(ROLE)}</text>
        <text x="{card_x+card_w/2}" y="{avatar_cy+avatar_r+76}" text-anchor="middle" font-family="'Fira Code',monospace" font-size="12" fill="{sub}">{esc(HANDLE)}</text>

        <line x1="{card_x+20}" y1="{card_y+card_h-58}" x2="{card_x+card_w-20}" y2="{card_y+card_h-58}" stroke="{glassBorder}"/>
        <g transform="translate({card_x+card_w/2-barcode_w/2},{card_y+card_h-46})" fill="#e9e9f2">
          <rect x="0" y="0" width="{barcode_w}" height="30" fill="#e9e9f2"/>
          {''.join(bars)}
        </g>
      </g>
    </g>
  </g>
</svg>'''

open('/home/claude/work/pkg/lanyard.svg','w').write(svg)
print("done", len(svg))
