import sys, os, base64
sys.path.insert(0, '/home/claude/work')
from text_to_path import text_to_path

FONT = "/usr/share/fonts/opentype/dancingscript/DancingScript-Bold.otf"
AVATAR_B64 = open('/home/claude/work/portrait_final.png.b64').read().strip() if os.path.exists('/home/claude/work/portrait_final.png.b64') else None

W, H = 1280, 760
NAME = "Ehtasham Khalid"
ROLES = ["Electrical Engineer", "Web Developer", "Hardware + Software Tinkerer"]
TAGLINE = "Make yourself unstoppable."
SKILLS = ["HTML", "CSS", "JavaScript", "React", "Next.js", "C / C++", "Arduino", "PCB Design", "MATLAB"]
NEON = "KEEP CODING \u2022 KEEP GROWING"

def name_paths_svg(font_size, x0, y0, letter_spacing=1.5, start_delay=2.7, stagger=0.075, dur_total=None):
    paths, total_w = text_to_path(NAME, FONT, font_size, x_start=0, y_start=0, letter_spacing=letter_spacing)
    out = []
    i = 0
    for ch, (d, tx, ty, scale) in zip([c for c in NAME if c != ' '], paths):
        delay = start_delay + i * stagger
        out.append(f'''<path d="{d}" transform="translate({x0+tx},{y0}) scale({scale},{-scale})" fill="url(#nameGrad)" opacity="0">
      <animate attributeName="opacity" from="0" to="1" begin="{delay:.3f}s" dur="0.35s" fill="freeze" calcMode="spline" keySplines="0.2 0.8 0.2 1"/>
      <animateTransform attributeName="transform" type="translate" additive="sum"
        values="0,18; 0,0" begin="{delay:.3f}s" dur="0.4s" fill="freeze" calcMode="spline" keySplines="0.2 0.8 0.2 1"/>
    </path>''')
        i += 1
    return "\n".join(out), total_w

def esc(s):
    return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

def build(light=False):
    if light:
        bg1, bg2, bg3 = "#fbeaf5", "#f3e2ff", "#ffffff"
        ink = "#3a1250"
        sub = "#7a4a95"
        card = "#ffffffcc"
        stroke = "#e6c8f5"
        pinkA, purpA = "#d6357f", "#8b3fd1"
        term_bg = "#2b1240"
        term_ink = "#f4d9ff"
    else:
        bg1, bg2, bg3 = "#1a0b2e", "#3a1256", "#12081d"
        ink = "#f6e9ff"
        sub = "#d9b3f0"
        card = "#ffffff14"
        stroke = "#ffffff26"
        pinkA, purpA = "#ff5fb0", "#b26bff"
        term_bg = "#00000055"
        term_ink = "#ffd9f0"

    name_group, name_w = name_paths_svg(78, 0, 0, start_delay=2.6)

    # role cycling text blocks (crossfade)
    role_dur = 2.4
    n_roles = len(ROLES)
    cycle = role_dur * n_roles
    role_blocks = []
    for idx, r in enumerate(ROLES):
        beg = 3.6 + idx * role_dur
        role_blocks.append(f'''<text x="0" y="0" font-family="'Courier New',monospace" font-size="26" fill="{pinkA}" opacity="0">{esc(r)}
      <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;0.08;0.85;1" dur="{cycle:.2f}s" begin="{beg:.2f}s" repeatCount="indefinite"/>
    </text>''')
    role_group = "\n".join(role_blocks)

    # tech pills
    pills = []
    px = 0
    pill_h = 34
    row_y = [0, 46]
    row = 0; px = 0
    for i, s in enumerate(SKILLS):
        wpx = 18 + len(s) * 9.2
        if px + wpx > 560:
            row += 1; px = 0
        y = row_y[row] if row < 2 else row_y[1] + 46*(row-1)
        delay = 5.6 + i * 0.12
        pills.append(f'''<g class="pill" transform="translate({px},{y})" opacity="0">
      <animate attributeName="opacity" from="0" to="1" begin="{delay:.2f}s" dur="0.45s" fill="freeze"/>
      <animateTransform attributeName="transform" type="translate" additive="sum" values="0,10;0,0" begin="{delay:.2f}s" dur="0.45s" fill="freeze" calcMode="spline" keySplines="0.2 0.8 0.2 1"/>
      <rect width="{wpx:.0f}" height="{pill_h}" rx="17" fill="{card}" stroke="{stroke}"/>
      <text x="{wpx/2:.0f}" y="22" text-anchor="middle" font-family="'Segoe UI',sans-serif" font-size="14" font-weight="600" fill="{ink}">{esc(s)}</text>
    </g>''')
        px += wpx + 12
    pills_group = "\n".join(pills)

    about_lines = [
        "Electrical Engineer who ended up falling in love with code.",
        "I build small hardware ideas and turn them into real, working apps.",
    ]
    about_group = "\n".join(
        f'''<text x="0" y="{i*26}" font-family="'Segoe UI',sans-serif" font-size="15.5" fill="{sub}" opacity="0">{esc(t)}
      <animate attributeName="opacity" from="0" to="1" begin="{7.0+i*0.3:.2f}s" dur="0.5s" fill="freeze"/>
    </text>''' for i, t in enumerate(about_lines)
    )

    # animated stat bar (profile momentum, purely decorative/local)
    stat_label = "Currently shipping: ISSB App"
    stat_pct = 82

    # code editor lines (typing buildDreams)
    code_lines = [
        ("const", "buildDreams", " = (", "ideas", ") => {"),
        ("  return", " ideas", ".map(idea =>"),
        ("    idea", ".code().test().ship()", ""),
        ("  );"),
        ("};"),
    ]
    code_plain = [
        "const buildDreams = (ideas) => {",
        "  return ideas.map(idea =>",
        "    idea.code().test().ship()",
        "  );",
        "};",
    ]
    code_group = []
    for i, line in enumerate(code_plain):
        w = len(line) * 8.6 + 10
        beg = 9.2 + i * 0.9
        code_group.append(f'''<g transform="translate(20,{26+i*24})">
      <clipPath id="codeclip{i}"><rect x="0" y="-16" width="0" height="24">
        <animate attributeName="width" from="0" to="{w:.0f}" begin="{beg:.2f}s" dur="0.8s" fill="freeze" calcMode="spline" keySplines="0.2 0.8 0.2 1"/>
      </rect></clipPath>
      <text clip-path="url(#codeclip{i})" font-family="'Fira Code','Courier New',monospace" font-size="15" fill="{'#ffd9f0' if not light else '#5a2472'}">{esc(line)}</text>
    </g>''')
    code_group_svg = "\n".join(code_group)
    caret_beg = 9.2 + len(code_plain)*0.9

    # ambient particles / hearts / sparkles / orbs
    import random
    random.seed(7)
    particles = []
    for i in range(14):
        x = random.uniform(20, W-20)
        y0 = random.uniform(H*0.5, H)
        dur = random.uniform(6, 11)
        delay = random.uniform(0, 8)
        r = random.uniform(1.4, 3.2)
        col = random.choice([pinkA, purpA, "#ffffff"])
        particles.append(f'''<circle cx="{x:.0f}" cy="{y0:.0f}" r="{r:.1f}" fill="{col}" opacity="0">
      <animate attributeName="opacity" values="0;0.8;0" dur="{dur:.1f}s" begin="{delay:.1f}s" repeatCount="indefinite"/>
      <animateTransform attributeName="transform" type="translate" values="0,0; 0,{-(H*0.5):.0f}" dur="{dur:.1f}s" begin="{delay:.1f}s" repeatCount="indefinite"/>
    </circle>''')
    hearts = []
    heart_path = "M0,-4 C-4,-9 -11,-6 -11,0 C-11,6 -4,9 0,14 C4,9 11,6 11,0 C11,-6 4,-9 0,-4 Z"
    for i in range(5):
        x = random.uniform(60, W-60)
        delay = random.uniform(0, 9) + i*1.6
        dur = random.uniform(7,10)
        hearts.append(f'''<path d="{heart_path}" transform="translate({x:.0f},{H+20}) scale(0.7)" fill="{pinkA}" opacity="0">
      <animate attributeName="opacity" values="0;0.55;0" dur="{dur:.1f}s" begin="{delay:.1f}s" repeatCount="indefinite"/>
      <animateTransform attributeName="transform" type="translate" additive="sum" values="0,0;{random.uniform(-30,30):.0f},{-(H+60):.0f}" dur="{dur:.1f}s" begin="{delay:.1f}s" repeatCount="indefinite"/>
    </path>''')
    sparkles = []
    spark_path = "M0,-6 L1.4,-1.4 L6,0 L1.4,1.4 L0,6 L-1.4,1.4 L-6,0 L-1.4,-1.4 Z"
    for i in range(8):
        x = random.uniform(20, W-20); y = random.uniform(20, H*0.6)
        delay = random.uniform(0,6); dur = random.uniform(2.4,4)
        s = random.uniform(0.5,1.1)
        sparkles.append(f'''<path d="{spark_path}" transform="translate({x:.0f},{y:.0f}) scale({s:.2f})" fill="#ffffff" opacity="0">
      <animate attributeName="opacity" values="0;0.9;0" dur="{dur:.1f}s" begin="{delay:.1f}s" repeatCount="indefinite"/>
      <animateTransform attributeName="transform" type="rotate" additive="sum" values="0;180" dur="{dur:.1f}s" begin="{delay:.1f}s" repeatCount="indefinite"/>
    </path>''')
    orbs = []
    for i in range(4):
        x = random.uniform(100, W-100); y = random.uniform(80, H-80); r = random.uniform(60,110)
        col = random.choice([pinkA, purpA])
        orbs.append(f'''<circle cx="{x:.0f}" cy="{y:.0f}" r="{r:.0f}" fill="{col}" opacity="0.05" filter="url(#bigblur)">
      <animate attributeName="opacity" values="0.04;0.11;0.04" dur="{random.uniform(4,7):.1f}s" repeatCount="indefinite"/>
    </circle>''')

    particles_svg = "\n".join(particles)
    hearts_svg = "\n".join(hearts)
    sparkles_svg = "\n".join(sparkles)
    orbs_svg = "\n".join(orbs)

    # terminal typing
    term_text = "user@dev:~$ cat README.md"
    term_w = len(term_text) * 10.4 + 20

    # avatar card geometry
    card_x, card_y, card_w, card_h = 800, 40, 430, 430
    avatar_w, avatar_h = 360, 368
    av_x = card_x + (card_w-avatar_w)/2
    av_y = card_y + 30

    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">
  <defs>
    <clipPath id="roundedBanner"><rect x="0" y="0" width="{W}" height="{H}" rx="28" ry="28"/></clipPath>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="{bg1}"/>
      <stop offset="55%" stop-color="{bg2}"/>
      <stop offset="100%" stop-color="{bg3}"/>
      <animate attributeName="x1" values="0%;20%;0%" dur="14s" repeatCount="indefinite"/>
      <animate attributeName="x2" values="100%;80%;100%" dur="14s" repeatCount="indefinite"/>
    </linearGradient>
    <linearGradient id="nameGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="{pinkA}"/>
      <stop offset="50%" stop-color="{purpA}"/>
      <stop offset="100%" stop-color="{pinkA}"/>
      <animate attributeName="x1" values="-40%;60%;-40%" dur="6s" repeatCount="indefinite"/>
      <animate attributeName="x2" values="60%;160%;60%" dur="6s" repeatCount="indefinite"/>
    </linearGradient>
    <filter id="bigblur" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="30"/></filter>
    <filter id="softblur" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="4"/></filter>
    <clipPath id="avatarClip"><rect x="{av_x:.0f}" y="{av_y:.0f}" width="{avatar_w}" height="{avatar_h}" rx="16" ry="16"/></clipPath>
    <clipPath id="cardClip"><rect x="{card_x}" y="{card_y}" width="{card_w}" height="{card_h}" rx="22" ry="22"/></clipPath>
  </defs>

  <g clip-path="url(#roundedBanner)">
    <rect x="0" y="0" width="{W}" height="{H}" fill="url(#bgGrad)"/>
    {orbs_svg}
    {particles_svg}
    {hearts_svg}
    {sparkles_svg}

    <!-- terminal line -->
    <g transform="translate(54,50)">
      <rect x="-14" y="-24" width="{term_w:.0f}" height="34" rx="8" fill="{term_bg}"/>
      <clipPath id="termclip"><rect x="0" y="-16" width="0" height="24">
        <animate attributeName="width" from="0" to="{term_w-24:.0f}" begin="0.4s" dur="1.6s" fill="freeze" calcMode="spline" keySplines="0.3 0.8 0.2 1"/>
      </rect></clipPath>
      <text clip-path="url(#termclip)" font-family="'Fira Code','Courier New',monospace" font-size="16.5" fill="{term_ink}">{esc(term_text)}</text>
      <rect x="0" y="-16" width="9" height="20" fill="{term_ink}" opacity="0">
        <animate attributeName="x" from="0" to="{term_w-24:.0f}" begin="0.4s" dur="1.6s" fill="freeze" calcMode="spline" keySplines="0.3 0.8 0.2 1"/>
        <animate attributeName="opacity" values="1;0;1" dur="0.9s" begin="2.0s" repeatCount="indefinite"/>
      </rect>
    </g>

    <!-- name -->
    <g transform="translate(50,178)">
      {name_group}
    </g>

    <!-- cycling role -->
    <g transform="translate(56,222)">
      <text x="-20" y="8" font-family="'Fira Code',monospace" font-size="22" fill="{pinkA}" opacity="0.9">&gt;</text>
      {role_group}
      <rect x="{20}" y="-18" width="3" height="22" fill="{pinkA}">
        <animate attributeName="opacity" values="1;0;1" dur="0.8s" repeatCount="indefinite"/>
      </rect>
    </g>

    <!-- quote box -->
    <g transform="translate(54,252)">
      <rect x="0" y="0" width="560" height="46" rx="10" fill="{card}" stroke="{stroke}"/>
      <text x="16" y="20" font-family="'Segoe UI',sans-serif" font-size="13" fill="{sub}" opacity="0.85">&#8220;</text>
      <clipPath id="quoteclip"><rect x="16" y="14" width="0" height="24">
        <animate attributeName="width" from="0" to="450" begin="4.6s" dur="1.6s" fill="freeze" calcMode="spline" keySplines="0.3 0.8 0.2 1"/>
      </rect></clipPath>
      <text clip-path="url(#quoteclip)" x="16" y="32" font-family="'Segoe UI',sans-serif" font-style="italic" font-size="17" font-weight="600" fill="{ink}">{esc(TAGLINE)}</text>
    </g>

    <!-- tech pills -->
    <g transform="translate(54,320)">
      {pills_group}
    </g>

    <!-- about -->
    <g transform="translate(54,436)">
      {about_group}
    </g>

    <!-- stat bar -->
    <g transform="translate(54,488)">
      <text x="0" y="0" font-family="'Segoe UI',sans-serif" font-size="13" fill="{sub}">{esc(stat_label)}</text>
      <rect x="0" y="10" width="420" height="10" rx="5" fill="{card}" stroke="{stroke}"/>
      <rect x="0" y="10" width="0" height="10" rx="5" fill="url(#nameGrad)">
        <animate attributeName="width" from="0" to="{420*stat_pct/100:.0f}" begin="7.6s" dur="1.4s" fill="freeze" calcMode="spline" keySplines="0.2 0.8 0.2 1"/>
      </rect>
    </g>

    <!-- neon sign -->
    <g transform="translate(940,516)">
      <text x="0" y="0" text-anchor="middle" font-family="'Segoe UI',sans-serif" font-size="21" font-weight="700" letter-spacing="1" fill="{pinkA}" opacity="0" filter="url(#softblur)">{esc(NEON)}</text>
      <text x="0" y="0" text-anchor="middle" font-family="'Segoe UI',sans-serif" font-size="21" font-weight="700" letter-spacing="1" fill="{pinkA}" opacity="0">{esc(NEON)}
        <animate attributeName="opacity" values="0;0;1;0.4;1;1;0.5;1;1" keyTimes="0;0.55;0.58;0.6;0.63;0.85;0.87;0.9;1" dur="4.4s" begin="8.4s" fill="freeze"/>
      </text>
    </g>

    <!-- code editor card -->
    <g transform="translate(800,540)">
      <rect x="0" y="0" width="430" height="150" rx="14" fill="{'#00000040' if not light else '#ffffffb0'}" stroke="{stroke}"/>
      <circle cx="18" cy="16" r="5" fill="#ff5f57"/>
      <circle cx="34" cy="16" r="5" fill="#febc2e"/>
      <circle cx="50" cy="16" r="5" fill="#28c840"/>
      {code_group_svg}
      <rect x="20" y="{10+len(code_plain)*24}" width="9" height="16" fill="{pinkA}" opacity="0">
        <animate attributeName="opacity" values="1;0;1" begin="{caret_beg:.2f}s" dur="0.8s" repeatCount="indefinite"/>
      </rect>
    </g>

    <!-- character portrait card with hologram reveal -->
    <g transform="translate(0,0)">
      <rect x="{card_x}" y="{card_y}" width="{card_w}" height="{card_h}" rx="22" fill="{card}" stroke="{stroke}"/>
      <g clip-path="url(#avatarClip)">
        <rect x="{av_x:.0f}" y="{av_y:.0f}" width="{avatar_w}" height="{avatar_h}" fill="{'#241033' if not light else '#f6ddff'}"/>
        <g>
          <clipPath id="holoReveal"><rect x="{av_x:.0f}" y="{av_y:.0f}" width="{avatar_w}" height="0">
            <animate attributeName="height" from="0" to="{avatar_h}" begin="1.0s" dur="1.6s" fill="freeze" calcMode="spline" keySplines="0.25 0.7 0.3 1"/>
          </rect></clipPath>
          <g clip-path="url(#holoReveal)">
            {'<image href="data:image/png;base64,' + AVATAR_B64 + '" x="' + f"{av_x:.0f}" + '" y="' + f"{av_y:.0f}" + '" width="' + str(avatar_w) + '" height="' + str(avatar_h) + '" preserveAspectRatio="xMidYMid slice"/>' if AVATAR_B64 else ''}
          </g>
          <!-- leading scan line for the one-time reveal -->
          <rect x="{av_x:.0f}" y="{av_y:.0f}" width="{avatar_w}" height="4" fill="{pinkA}" opacity="0.9">
            <animate attributeName="y" from="{av_y:.0f}" to="{av_y+avatar_h:.0f}" begin="1.0s" dur="1.6s" fill="freeze" calcMode="spline" keySplines="0.25 0.7 0.3 1"/>
            <animate attributeName="opacity" values="0.9;0.9;0" begin="1.0s" dur="1.8s" fill="freeze"/>
          </rect>
        </g>
        <!-- continuous horizontal scanner -->
        <rect x="{av_x:.0f}" y="{av_y:.0f}" width="{avatar_w}" height="10" fill="{pinkA}" opacity="0.35">
          <animate attributeName="y" values="{av_y:.0f};{av_y+avatar_h:.0f};{av_y:.0f}" keyTimes="0;0.5;1" dur="3.5s" begin="2.6s" repeatCount="indefinite" calcMode="linear"/>
          <animate attributeName="opacity" values="0.35;0.1;0.35" dur="3.5s" begin="2.6s" repeatCount="indefinite"/>
        </rect>
      </g>
      <text x="{card_x+card_w/2:.0f}" y="{card_y+card_h-16}" text-anchor="middle" font-family="'Fira Code',monospace" font-size="13" fill="{sub}">&lt;/&gt; Code. Coffee. Repeat.</text>
    </g>
  </g>
  <style>
    .pill:hover rect {{ transform-origin: center; }}
    .pill:hover {{ filter: brightness(1.15); }}
  </style>
</svg>'''
    return svg

if __name__ == '__main__':
    dark = build(light=False)
    open('/home/claude/work/pkg/banner.svg','w').write(dark)
    light = build(light=True)
    open('/home/claude/work/pkg/banner-light.svg','w').write(light)
    print("done", len(dark), len(light))
